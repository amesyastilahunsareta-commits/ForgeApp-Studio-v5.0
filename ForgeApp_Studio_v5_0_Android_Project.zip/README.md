# ForgeApp Studio v5.0 Android project

This is an Android WebView wrapper around `app/src/main/assets/index.html`.

## Build a free debug APK with GitHub Actions
1. Create a GitHub repository and upload the contents of this project ZIP (upload the files/folders, not the ZIP as a single source file).
2. Open the repository's **Actions** tab.
3. Select **Build ForgeApp Studio APK** and tap **Run workflow** if it has not run automatically.
4. When the run succeeds, open it and download the artifact **ForgeApp-Studio-v5-APK**.
5. Extract the downloaded artifact ZIP and install `app-debug.apk` on your Android phone. Android may ask you to allow installs from that browser/file manager.

## Important limits
- This ZIP is a build project, not an APK.
- The HTML currently displays simulated build logs. Its Export App and Owner Transfer buttons only show alerts; they do not generate an APK or downloadable HTML package.
- The page uses external CDNs for Tailwind, Font Awesome, and Google Fonts, so those visual assets require internet access.
- This produces a debug APK for testing, not a Play Store release.
